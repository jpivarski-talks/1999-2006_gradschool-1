cas2f = par1 + par2 * (x - 9.4584) + par3 * (x^2 - 18.922*x + 89.513);
s1 = 9.441;
s2 = 9.454;
s3 = 9.472;
s4 = 9.480;

sid = Integrate[cas2f, {x, s1, s2}] + Integrate[cas2f, {x, s3, s4}];
sig = Integrate[cas2f, {x, s2, s3}];

FortranForm[FullSimplify[sig/sid]]

sigma scale0 = 0.8003 + (21.146*par1        + 1.47944* par2      )/ (371.98*par1        - 0.015942*par2 + par3)
sigma scale1 = 0.8003 + (21.146*(par1+err1) + 1.47944* par2      )/ (371.98*(par1+err1) - 0.015942*par2 + par3)
sigma scale2 = 0.8003 + (21.146*par1        + 1.47944*(par2+err2))/ (371.98*par1        - 0.015942*(par2+err2) + par3)
sigma scale3 = 0.8003 + (21.146*par1        + 1.47944* par2      )/ (371.98*par1        - 0.015942*par2 + (par3 + err3))

